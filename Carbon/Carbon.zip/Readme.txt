08.21.2008 - Initial Release (v1.0)
10.12.2008 - Modified List Panel Background (v1.1)
07.15.2009 - Fixed Support Button (v1.2)
07.21.2009 - Minor bug fixes found in current Steam beta (v1.21)
08.27.2009 - Resolved issue with new email verification process (v1.22)

Extract the contents to your Steam skins directory (usually C:\Program Files\Steam\skins\).

Note that there are two versions of this skin. One version is for English users; it is called "Carbon". The other version is for any one who does not speak English; it is called "Carbon (Non-English)." You only need to extract the version you want to use.

Included icons, created by Vaksa (http://vaksa.deviantart.com), used with permission.

--------------------------------------------------
This file is not to be uploaded to/distributed by any web site/organization/individual without my consent.
Copyright Ryan Thaut (2007-2008). All rights reserved. No modification or distribution without my written permission.

http://www.rynostudios.com/