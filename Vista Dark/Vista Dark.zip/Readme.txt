10.07.2007 - Initial Release (v2.0)
10.23.2007 - Proper Release (v2.1)

Extract the contents to your Steam skins directory (usually C:\Program Files\Steam\skins\).

Included icons, created by Vaksa (http://vaksa.deviantart.com), used with permission.

--------------------------------------------------
This file is not to be uploaded to/distributed by any web site/organization/individual except deviantART.
Copyright Ryan Thaut (2007). All rights reserved. No modification or distribution without my written permission.

http://www.rynostudios.com/