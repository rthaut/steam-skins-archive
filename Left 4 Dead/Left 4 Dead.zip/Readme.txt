06.30.2009 - Initial Release (v1.0)
07.03.2009 - Fixed Support Button and Compact Friends List (v1.01)
07.21.2009 - Minor bug fixes found in current Steam beta (v1.02)
08.09.2009 - Loading throbber and navigation icons adjusted (v1.03)
08.27.2009 - Resolved issue with new email verification process (v1.04)

Extract the contents to your Steam skins directory (usually C:\Program Files\Steam\skins\).

Included icons, created by Vaksa (http://vaksa.deviantart.com), used with permission.

Valve, The Valve logo, Left 4 Dead, the Left 4 Dead logo, Steam, the Steam logo, Source, the Source logo, and Valve Source are trademarks and/or registered tradmarks of Valve Corporation in the United States and other countries.

--------------------------------------------------
This file is not to be uploaded to/distributed by any web site/organization/individual without my consent.
Copyright Ryan Thaut (2009). All rights reserved. No modification or distribution without my written permission.

http://www.rynostudios.com/