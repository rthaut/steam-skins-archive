10.07.2007 - Initial Release (v1.0)
12.11.2007 - User Requested Changes (v1.1)
06.13.2009 - Changed Friends List Username Colors (v1.2)
07.21.2009 - Minor bug fixes found in current Steam beta (v1.21)
08.27.2009 - Resolved issue with new email verification process (v1.22)
01.02.2010 - Fixed the navigation buttons in the web browser overlay (v1.23)
01.17.2010 - Friend's chat text is now a seperate color than user's own text (v1.24)

Extract the contents to your Steam skins directory (usually C:\Program Files\Steam\skins\).

Included icons, created by Vaksa (http://vaksa.deviantart.com), used with permission.

--------------------------------------------------
This file is not to be uploaded to/distributed by any web site/organization/individual without my consent.
Copyright Ryan Thaut (2007-2010). All rights reserved. No modification or distribution without my written permission.

http://www.rynostudios.com/