2.16.2008 - Initial Release (v1.0)
08.27.2009 - Resolved issue with new email verification process (v1.01)

*Inspired by the design created by o2dazone from the Steam Users Forums.

Extract the contents to your Steam skins directory (usually C:\Program Files\Steam\skins\).

Included icons, created by Vaksa (http://vaksa.deviantart.com), used with permission.

--------------------------------------------------
This file is not to be uploaded to/distributed by any web site/organization/individual except deviantART.
Copyright Ryan Thaut (2007-2008). All rights reserved. No modification or distribution without my written permission.

http://www.rynostudios.com/