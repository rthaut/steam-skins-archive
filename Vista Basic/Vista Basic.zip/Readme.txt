Change Log:
- 10.07.2007 - Initial Release (v2.0)
- 10.23.2007 - Proper Release (v2.1)
- 11.30.2008 - Fixed Popup Notifications (v2.2)
- 09.30.2009 - Fixed Compact Friends List (v2.21)

Instructions: Extract the contents to your Steam skins directory (usually C:\Program Files\Steam\skins\).

Included icons, created by Vaksa (http://vaksa.deviantart.com), used with permission.

--------------------------------------------------
This file is not to be uploaded to/distributed by any web site/organization/individual without my consent.
Copyright Ryan Thaut (2009). All rights reserved. No modification or distribution without my written permission.

http://www.rynostudios.com/